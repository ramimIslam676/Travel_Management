﻿using Data.Layer.Entity;
using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace Final_Project
{
    public partial class CustomerForm : Form
    {
        Users CustomerUser;
        // string connectionString = "data source=DESKTOP-C095TBV\\SQLEXPRESS; database=KK; integrated security=SSPI";
        string connectionString = "Server=localhost;Database=travelmanagement;Uid=root;Pwd=;Port=3306;"; int trip_id;
        public CustomerForm(Users user, int trip_id)
        {
            InitializeComponent();
            CustomerUser = user;
            Console.WriteLine(user == null ? "User is NULL" : $"User: {user.UserName}");
            this.trip_id = trip_id;
            string query = "SELECT * FROM trip";
            LoadDataGridView(query);
        }
        private int AskForSeats(string tripName, string destination, decimal pricePerSeat, int availableSeats)
        {
            int selectedSeats = 0;

            using (Form prompt = new Form())
            {
                prompt.Width = 400;
                prompt.Height = 250;
                prompt.Text = "Select Number of Seats";
                prompt.StartPosition = FormStartPosition.CenterParent;

                Label textLabel = new Label()
                {
                    Left = 20,
                    Top = 20,
                    Width = 350,
                    Height = 60,
                    Text = $"Trip: {tripName}\nDestination: {destination}\nPrice per seat: ${pricePerSeat:F2}\nAvailable seats: {availableSeats}"
                };

                NumericUpDown seatSelector = new NumericUpDown()
                {
                    Left = 20,
                    Top = 100,
                    Width = 100,
                    Minimum = 1,
                    Maximum = availableSeats,
                    Value = 1
                };

                Button okButton = new Button()
                {
                    Text = "OK",
                    Left = 150,
                    Top = 150,
                    DialogResult = DialogResult.OK
                };

                prompt.Controls.Add(textLabel);
                prompt.Controls.Add(seatSelector);
                prompt.Controls.Add(okButton);
                prompt.AcceptButton = okButton;

                if (prompt.ShowDialog() == DialogResult.OK)
                {
                    selectedSeats = (int)seatSelector.Value;
                }
            }

            return selectedSeats;
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvTripInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {


        }
        private void LoadDataGridView(string query)
        {
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, con))
                {
                    con.Open();
                    MySqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    // Assuming your DataGridView is named FillDataGridView
                    FillDataGridView.DataSource = dataTable;
                }
            }
        }

        private void FillDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e,string query)
        {

             
        }


        private void button1_Click_1(object sender, EventArgs e)
        {

            if (FillDataGridView.SelectedRows.Count > 0)
            {
                try
                {
                    // Get trip information from the selected row
                    DataGridViewRow selectedRow = FillDataGridView.SelectedRows[0];

                    int tripId = Convert.ToInt32(selectedRow.Cells["trip_id"].Value);
                    string tripName = selectedRow.Cells["trip_name"].Value?.ToString() ?? "";
                    string destination = selectedRow.Cells["destination"].Value?.ToString() ?? "";
                    DateTime startDate = Convert.ToDateTime(selectedRow.Cells["start_date"].Value);
                    DateTime endDate = Convert.ToDateTime(selectedRow.Cells["end_date"].Value);
                    decimal pricePerSeat = Convert.ToDecimal(selectedRow.Cells["price"].Value);
                    int availableSeats = Convert.ToInt32(selectedRow.Cells["available_seat"].Value);
                    int totalSeats = Convert.ToInt32(selectedRow.Cells["total_seat"].Value);
                    string description = selectedRow.Cells["description"].Value?.ToString() ?? "";

                    // 🔹 Ask user for number of seats with custom popup
                    int requestedSeats = AskForSeats(tripName, destination, pricePerSeat, availableSeats);

                    if (requestedSeats <= 0) return; // user cancelled

                    // Validate requested seats
                    if (requestedSeats > availableSeats)
                    {
                        MessageBox.Show($"Sorry! Only {availableSeats} seats are available.",
                            "Insufficient Seats", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Calculate total price
                    decimal totalPrice = pricePerSeat * requestedSeats;

                    // Show confirmation
                    DialogResult result = MessageBox.Show(
                        $"Trip: {tripName}\n" +
                        $"Destination: {destination}\n" +
                        $"Date: {startDate:yyyy-MM-dd} to {endDate:yyyy-MM-dd}\n" +
                        $"Seats: {requestedSeats}\n" +
                        $"Price per seat: ${pricePerSeat:F2}\n" +
                        $"Total Price: ${totalPrice:F2}\n\n" +
                        "Proceed to payment?",
                        "Confirm Booking",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        // Create booking data
                        TripBookingData bookingData = new TripBookingData
                        {
                            TripId = tripId,
                            TripName = tripName,
                            Destination = destination,
                            StartDate = startDate,
                            EndDate = endDate,
                            PricePerSeat = pricePerSeat,
                            RequestedSeats = requestedSeats,
                            TotalPrice = totalPrice,
                            AvailableSeats = availableSeats,
                            TotalSeats = totalSeats,
                            Description = description,
                            CustomerUser = this.CustomerUser
                        };

                        // Open Payment form
                        Payment paymentForm = new Payment();
                        paymentForm.ShowDialog();

                        // Refresh after booking
                        RefreshTripData();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error processing trip selection: {ex.Message}",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a trip to book.",
                    "No Trip Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Helper method to refresh trip data
        private void RefreshTripData()
        {
            string query = "SELECT * FROM trip";
            LoadDataGridView(query);
        }
        public class TripBookingData
        {
            public int TripId { get; set; }
            public string TripName { get; set; }
            public string Destination { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public decimal PricePerSeat { get; set; }
            public int RequestedSeats { get; set; }
            public decimal TotalPrice { get; set; }
            public int AvailableSeats { get; set; }
            public int TotalSeats { get; set; }
            public string Description { get; set; }
            public Users CustomerUser { get; set; }
        }

        private void FillDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
    }

